create PROCEDURE DISPLAY_CUSTOMER_INFO (
    fValue      NUMBER,
    lValue      NUMBER
) 
IS
    --cusID       NUMBER;
    cusName     varchar2(50);
    cusPhone    varchar2(25);
    cusCountry  varchar2(30);
BEGIN
        FOR i IN fValue..lValue LOOP
        SELECT      CUST_NAME,
                    CUST_PHONE,
                    CUST_COUNTRY
        INTO        cusName,
                    cusPhone,
                    cusCountry
        FROM        s_customer
        WHERE       i = customer_id;
        DBMS_OUTPUT.PUT_LINE('Customer name:'||cusName||', Customer Phone Number: '||cusPhone||', Customer Country: '||cusCountry);

        END LOOP;
END;
/

