create function sayHi return varchar2 
IS
    str varchar2(20);
BEGIN
    str := 'Hello World!';
    return str;

END;
/

