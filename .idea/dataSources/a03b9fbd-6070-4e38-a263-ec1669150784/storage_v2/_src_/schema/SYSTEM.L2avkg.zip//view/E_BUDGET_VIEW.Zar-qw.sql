create view E_BUDGET_VIEW as
SELECT      dep.department_name AS "DEPT_NAME", 
                dep.budget_projected AS "BUD_PROJ", 
                dep.budget_actual AS "BUD_ACT",
                (dep.budget_actual - dep.budget_projected) AS "DIFF",
                emp.last_name ||', '||emp.first_name AS "MGR_NAME"
    
    FROM        e_departments dep
    JOIN        e_job_history job
    ON          (dep.department_code = job.department_code)
    JOIN        e_employees emp
    ON          (emp.employee_id = job.employee_id)
    
    WHERE       (emp.employee_id = dep.manager_id)
    AND         dep.budget_projected IS NOT NULL
    AND         dep.budget_actual IS NOT NULL
/

