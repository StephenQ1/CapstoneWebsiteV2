create trigger PRICE_INCREASE_CHECK
    before update
    on S_PRODUCT
    for each row
BEGIN
    if :NEW.SUGGESTED_WHLSL_PRICE / :OLD.SUGGESTED_WHLSL_PRICE >= 1.15 THEN 
        :NEW.SUGGESTED_WHLSL_PRICE := :OLD.SUGGESTED_WHLSL_PRICE * 1.15;
    end if;
end;
/

