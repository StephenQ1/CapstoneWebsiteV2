create function dayOfTheWeek(givenDate DATE) RETURN varchar2
IS
    dayResult VARCHAR2(10);
BEGIN
    dayResult := to_char(givenDate, 'Day');
    return dayResult;
End;
/

