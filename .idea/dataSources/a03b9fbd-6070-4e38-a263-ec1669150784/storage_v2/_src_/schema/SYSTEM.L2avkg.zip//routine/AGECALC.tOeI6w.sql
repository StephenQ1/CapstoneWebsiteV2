create function ageCalc(dob DATE) return number

IS
    age number;
BEGIN
    age := TRUNC((SYSDATE-dob)/ 365.24);
    return age;
END;
/

