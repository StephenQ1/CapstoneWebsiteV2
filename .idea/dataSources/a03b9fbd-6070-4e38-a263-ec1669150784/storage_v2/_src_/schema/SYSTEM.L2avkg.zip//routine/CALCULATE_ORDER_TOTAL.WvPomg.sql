create function CALCULATE_ORDER_TOTAL (
order_date DATE
)
return NUMBER
IS 
    total_for_day NUMBER;

BEGIN
    select SUM(total) into total_for_day
    from s_ord
    where order_date = date_ordered;

    return total_for_day;
END;
/

