create view CURRENT_JOB as
SELECT employee_id, last_name, first_name, job_code, department_code, supervisor_id, job_start
FROM e_employees JOIN e_job_history USING (employee_id)
WHERE job_end is NULL
/

